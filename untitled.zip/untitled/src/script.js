// JS (CodePen)

// ✅ نصوص جديدة حسب طلبك
const texts = [
  // سهل: بسيط وقليل
  `أنا أحب القراءة.
القراءة تساعدني.
أقرأ كل يوم قليلًا.`,

  // متوسط: نصوص مو كثيرة
  `القراءة عادة مفيدة في الدراسة والحياة. عندما تقرأ بهدوء وتفهم المعنى، تصبح كلماتك أقوى وتزيد ثقتك. خصص عشر دقائق يوميًا، ثم زد الوقت تدريجيًا.`,
  
  // عالي: طويل + تعبيرات
  `في عالمٍ يتغير بسرعة، تصبح القراءة أشبه ببوصلةٍ ذكية تُعيد ترتيب أفكارنا وسط الضجيج. قد تبدأ الصفحة الأولى وكأنها مجرد كلماتٍ متتابعة، ثم فجأة—وبلا إنذار—تشعر أن فكرةً ما “لمستك”؛ تُوقظ سؤالًا قديمًا، أو تفتح نافذةً على احتمالٍ جديد. القارئ الجيد لا يكتفي بمتابعة الجمل، بل يلتقط النبرة، ويلاحظ التلميحات، ويقارن بين المعاني كما لو أنه يحل لغزًا لطيفًا.

وحين نقرأ بتأنٍّ، نتعلم مهارة التوازن: لا نبتلع المعلومة بسرعة، ولا نتوقف عند كل كلمةٍ بشكلٍ مرهق. نُصغي للنص، ثم نرد عليه بعقلٍ ناقد: ما الدليل؟ ما الفكرة الرئيسية؟ هل توجد مبالغة؟ وهل يمكن تفسير ذلك بطريقةٍ أخرى؟ هنا تتحول القراءة إلى حوارٍ داخليٍّ ممتع، يرفع مستوى الفهم ويُحسن التعبير—بل ويمنحنا قدرةً أفضل على اتخاذ القرار.`
];

// عناصر
const targetEl = document.getElementById("target");
const spokenEl = document.getElementById("spoken");
const timerEl  = document.getElementById("timer");
const statusEl = document.getElementById("status");
const supportMsg = document.getElementById("supportMsg");

const wpmEl = document.getElementById("wpm");
const accEl = document.getElementById("acc");
const levelEl = document.getElementById("level");
const notesEl = document.getElementById("notes");
const detailsEl = document.getElementById("details");

const startBtn = document.getElementById("startBtn");
const stopBtn  = document.getElementById("stopBtn");

const fontDec = document.getElementById("fontDec");
const fontInc = document.getElementById("fontInc");
const fontReset = document.getElementById("fontReset");
const fontSizeLabel = document.getElementById("fontSizeLabel");

// تحميل أزرار النصوص
document.querySelectorAll("[data-load]").forEach(btn=>{
  btn.addEventListener("click", ()=> loadText(Number(btn.dataset.load)));
});

// ✅ تحكم بحجم الخط
let fontSize = 16;          // الافتراضي
const MIN_FONT = 12;
const MAX_FONT = 28;
const STEP = 2;

function applyFontSize(){
  targetEl.style.fontSize = fontSize + "px";
  spokenEl.style.fontSize = fontSize + "px";
  fontSizeLabel.textContent = fontSize + "px";
}

fontInc.addEventListener("click", ()=>{
  fontSize = Math.min(MAX_FONT, fontSize + STEP);
  applyFontSize();
});

fontDec.addEventListener("click", ()=>{
  fontSize = Math.max(MIN_FONT, fontSize - STEP);
  applyFontSize();
});

fontReset.addEventListener("click", ()=>{
  fontSize = 16;
  applyFontSize();
});

// بدء
applyFontSize();
loadText(0);

let rec = null;
let startTime = 0;
let tInt = null;
let finalTranscript = "";

function loadText(i){
  targetEl.value = texts[i];
  spokenEl.value = "";
  resetResults();
  timerEl.textContent = "الوقت: 0.0 ث";
  statusEl.textContent = "الحالة: جاهز";
  supportMsg.textContent = "";
}

function resetResults(){
  wpmEl.textContent = "السرعة: -";
  accEl.textContent = "الدقة: -";
  levelEl.textContent = "المستوى: -";
  notesEl.textContent = "";
  detailsEl.textContent = "";
}

function normalizeArabic(s){
  return (s || "")
    .toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g, "")                 // حذف الحركات
    .replace(/[“”"]/g, "")
    .replace(/[^\u0600-\u06FF0-9\s]/g, " ")      // حذف الرموز
    .replace(/\s+/g, " ")
    .trim();
}

// LCS length on word tokens (تقريب تطابق الكلمات)
function lcsLen(a, b){
  const n = a.length, m = b.length;
  const dp = Array.from({length:n+1}, ()=>Array(m+1).fill(0));
  for(let i=1;i<=n;i++){
    for(let j=1;j<=m;j++){
      dp[i][j] = (a[i-1]===b[j-1]) ? dp[i-1][j-1]+1 : Math.max(dp[i-1][j], dp[i][j-1]);
    }
  }
  return dp[n][m];
}

function estimateLevel(wpm, acc){
  // قواعد بسيطة (تقدر تعدلها)
  if(acc >= 0.90 && wpm >= 130) return "متقدم";
  if(acc >= 0.75 && wpm >= 90)  return "متوسط";
  return "مبتدئ";
}

function calc(){
  const target = normalizeArabic(targetEl.value);
  const spoken = normalizeArabic(spokenEl.value);

  const targetWords = target ? target.split(" ") : [];
  const spokenWords = spoken ? spoken.split(" ") : [];

  const seconds = Math.max(0.1, (performance.now() - startTime) / 1000);
  const minutes = seconds / 60;

  const wpm = spokenWords.length ? (spokenWords.length / minutes) : 0;

  // accuracy via LCS / target length (تقريب)
  const lcs = lcsLen(targetWords, spokenWords);
  const acc = targetWords.length ? (lcs / targetWords.length) : 0;

  const level = estimateLevel(wpm, acc);

  wpmEl.textContent = `السرعة: ${Math.round(wpm)} كلمة/دقيقة`;
  accEl.textContent = `الدقة: ${Math.round(acc*100)}%`;
  levelEl.textContent = `المستوى: ${level}`;

  const advice =
    acc < 0.75
      ? "اقرأ أبطأ قليلًا وركّز على نطق الكلمات بوضوح."
      : (wpm < 90 ? "حاول ترفع السرعة تدريجيًا مع الحفاظ على الدقة." : "ممتاز! جرّب قراءة نص أطول لقياس أدق.");

  notesEl.innerHTML = `<span class="${acc>=0.75?'ok':'bad'}">نصيحة:</span> ${advice}`;

  detailsEl.textContent =
`تفاصيل سريعة:
- كلمات النص الأصلي: ${targetWords.length}
- كلمات التفريغ الصوتي: ${spokenWords.length}
- كلمات متطابقة تقريبًا (LCS): ${lcs}
- الوقت: ${seconds.toFixed(1)} ثانية
ملاحظة: التفريغ الصوتي يعتمد على دعم المتصفح/النظام وقد يخطئ أحيانًا.`;
}

function startRec(){
  resetResults();
  finalTranscript = "";
  spokenEl.value = "";

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SpeechRecognition){
    supportMsg.textContent = "⚠️ متصفحك لا يدعم Speech Recognition. جرّب Safari على iPhone أو Chrome/Edge على الكمبيوتر.";
    return;
  }

  supportMsg.textContent = "";
  rec = new SpeechRecognition();
  rec.lang = "ar-SA";
  rec.continuous = true;
  rec.interimResults = true;

  rec.onstart = () => {
    statusEl.textContent = "الحالة: يسجل الآن...";
    startBtn.disabled = true;
    stopBtn.disabled = false;
    startTime = performance.now();
    tInt = setInterval(()=>{
      const s = (performance.now() - startTime) / 1000;
      timerEl.textContent = `الوقت: ${s.toFixed(1)} ث`;
    }, 100);
  };

  rec.onerror = (e) => {
    statusEl.textContent = "الحالة: خطأ";
    supportMsg.textContent = "⚠️ خطأ في التسجيل: " + (e.error || "غير معروف");
    stopRec();
  };

  rec.onresult = (event) => {
    let interim = "";
    for(let i = event.resultIndex; i < event.results.length; i++){
      const txt = event.results[i][0].transcript;
      if(event.results[i].isFinal) finalTranscript += txt + " ";
      else interim += txt;
    }
    spokenEl.value = (finalTranscript + interim).trim();
  };

  rec.onend = () => {
    statusEl.textContent = "الحالة: تم الإيقاف";
    startBtn.disabled = false;
    stopBtn.disabled = true;
    clearInterval(tInt);
    calc();
  };

  rec.start();
}

function stopRec(){
  try{ if(rec) rec.stop(); }catch(e){}
  clearInterval(tInt);
}

// أزرار التشغيل
startBtn.addEventListener("click", startRec);
stopBtn.addEventListener("click", stopRec);